function ftp_ls {
    # this function prints list of file to a file.
	# Note. If you are not downloading the entire folder you may be interested in the last modification date of a single file. check ftp_file_date.
	# FTP_URL=$1
	# FOLDER=$2
	local OPTIND
	while getopts ":f:" OPTIONS; do
	    case $OPTIONS in
	        f)
	          local FILENAME=$OPTARG
	          ;;
	        \?)
	          echo "unrecognized option: -$OPTARG" >&2
              ;;
	    esac
	done
	shift $((OPTIND-1))
	PATTERN=${3:-''}
	files_array=$(lftp $1 <<- GRAB | grep "$PATTERN" | awk '{print $9}'
	quote USER anonymous
	quote PASS
	cd $2
	ls
	quit
	GRAB
	)
	if [[ -z ${FILENAME} ]]; then
		echo ${files_array}
	else
	    printf "%s\n" "${files_array[@]}" > ${FILENAME}
	fi
}

TMPDIR=$1
mkdir -p ${TMPDIR}

# URL:  https://ftp.ensemblgenomes.ebi.ac.uk/pub/plants/current/json/

ALL_FOLDERS=($(ftp_ls "ftp.ensemblgenomes.ebi.ac.uk" "pub/plants/current/json/"))


# Download the main gene files into a tmp-directory
for folder in "${ALL_FOLDERS[@]}"; do
    echo "Downloading ${folder}.json"
    wget -nv -q -O "${TMPDIR}/ensembl.${folder}.json" "https://ftp.ensemblgenomes.ebi.ac.uk/pub/plants/current/json/${folder}/${folder}.json"
done

# Find and delete any empty main files (some of the files on the Ensembl FTP are just empty)
echo "Removing empty files (if there are any) ..."
find ${TMPDIR} -empty -type f -delete -print

