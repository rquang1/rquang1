import os
import re

import xml.etree.ElementTree as ET
from xml.etree.ElementTree import ParseError
import requests
import json
import time
import multiprocessing as mp
from joblib import Parallel, delayed
from pathlib import Path

plugin_interface_version = 2


def log_in_citeline_api(credentials, log):
    url = credentials["url"]
    data = credentials["data"]
    usrpass = credentials["usrpass"]
    response = requests.post(url, data=data, headers={"Authorization": "Basic %s" %usrpass})
    bearer_token = response.json()
    if "access_token" in bearer_token:
        access_token = bearer_token["access_token"]
    else:
        log("Error: Credential file did not allow correct login to the informa citeline api")
        exit(1)

    return access_token


def fill_credentials(usr, pwd):
    credentials = {"url": "https://identity.pharmaintelligence.informa.com/connect/token",
    "usrpass": "Y3VzdG9tZXJfYXBpX2NsaWVudF9uYXRpdmU6NTIwNzhjMGItMTI5Mi00MGVhLWFkYjAtOWE4MWY4OGNjZDMy",
    "data": {"grant_type":"password",
            "username":f"{usr}",
            "password":f"{pwd}",
            "scope":"customer-api"}}

    return credentials


def request_individual_instance_type(id_number, access_token, instance_type):
    try:
        instance_update = requests.get("https://api.pharmaintelligence.informa.com/v1/search/{}?id={}".format(instance_type, id_number),
                                       headers={"authorization": "Bearer %s" % access_token,
                                                "accept": "application/xml"})
        if not instance_update.text.__contains__('502 Bad Gateway') and not instance_update.text.__contains__(
                '504 Gateway Time-out') and instance_update.text:
            with open(os.path.join(f"/plugin/external/citeline/{instance_type}/{instance_type}_{id_number}.xml"), "w") as f:
                f.write(re.sub(r'&#([a-zA-Z0-9]+);?', r'[#\1;]', instance_update.text))
    except:
        pass


def incremental_download(log, credentials, instance_type, num_cores):
    access_token = log_in_citeline_api(credentials, log)

    collection_date = Path("/plugin/external/citeline/collection_date.json")
    if collection_date.is_file():
        collections = json.load(open(collection_date, "r"))
        date = collections["date_modified"]
        log(date)
        log(f"Searching update of trials since {date}")

        if not os.path.exists(f"/plugin/external/citeline/{instance_type}"):
            os.makedirs(f"/plugin/external/citeline/{instance_type}")

        instance_count_url = f"https://api.pharmaintelligence.informa.com/v1/feed/{instance_type}/changes/count/?since={date}"
        count_requst_awnser = requests.get(instance_count_url, headers={"authorization": "Bearer %s" % access_token, "accept": "application/xml"})
        instance_count = ET.fromstring(count_requst_awnser.text).findtext(".//Count")

        instance_url = f"https://api.pharmaintelligence.informa.com/v1/feed/{instance_type}/changes?since={date}"
        request_retries = 0
        current_count = 1
        while instance_url is not None:
            instance = requests.get(instance_url, headers={"authorization": "Bearer %s" % access_token, "accept": "application/xml"})
            try:
                root = ET.fromstring(re.sub(r'&#([a-zA-Z0-9]+);?', r'[#\1;]', instance.text))
                id_numbers_nodes = root.findall(".//" + instance_type.capitalize() + "Id" )
                id_numbers = [x.text for x in id_numbers_nodes]
                log("Found trial ID's to update: " + ", ".join(id_numbers))
                request_retries = 0
                if id_numbers:
                    try:
                        log(f"downloading {str(current_count)} out of {str(instance_count)} from page: {instance_url}")
                    except:
                        pass
                    Parallel(n_jobs=num_cores)(
                        delayed(request_individual_instance_type)(id_number, access_token, instance_type, instance_url)
                        for id_number in id_numbers)

                    current_count += len(id_numbers)
                instance_url = root.findtext(".//NextPage")

            except ParseError:
                log("api response is not valid xml for gotten from url: " + str(instance_url))
                if "Please generate a new bearer token" in instance.text:
                    log("Error due to outdated token. Regenerating..")
                    access_token = log_in_citeline_api(credentials, log)
                else:
                    with open(instance_type + "_error.xml", "a") as x:
                        x.write(instance.text)
                    if "NextPage" in instance.text:
                        instance_url = instance.text.split("<NextPage>")[1].split("</NextPage>")[0]
                        instance_url = instance_url.replace(";amp;", "%%%").replace("&amp;", "&").replace("%%%", ";")
                        log("continuing with page: " + str(instance_url))
                        current_count += 1
                    else:
                        if request_retries == 20:
                            log("could not find where to go next. Exiting. Retryied " + str(request_retries)  + " times")
                            exit(1)
                        else:
                            log("Invalid response. Retrying request (" + str(request_retries) + ")")
                            time.sleep(20)
                            request_retries += 1


def full_download(log, credentials, instance_type):
    access_token = log_in_citeline_api(credentials, log)

    if not os.path.exists(f"/plugin/external/citeline/{instance_type}"):
        os.makedirs(f"/plugin/external/citeline/{instance_type}")

    instance_count_url = f"https://api.pharmaintelligence.informa.com/v1/feed/{instance_type}/count"
    count_requst_awnser = requests.get(instance_count_url, headers={"authorization": "Bearer %s" % access_token,
                                                                    "accept": "application/xml"})
    instance_count = ET.fromstring(count_requst_awnser.text).findtext(".//Count")
    instance_url = f"https://api.pharmaintelligence.informa.com/v1/feed/{instance_type}?pagesize=1"
    request_retries = 0
    current_count = 1
    while instance_url is not None:
        log(f"downloading {str(current_count)} out of {str(instance_count)} from page: {instance_url}")
        instance = requests.get(instance_url, headers={"authorization": "Bearer %s" % access_token, "accept": "application/xml"})
        try:
            root = ET.fromstring(instance.text)
            id_number = root.findtext(".//" + instance_type.capitalize() + "Id")
            with open(os.path.join(f"plugin/external/citeline/{instance_type}/{instance_type}_{id_number}.xml"), "w") as f:
                f.write(instance.text)
            instance_url = root.findtext(".//NextPage")
            request_retries = 0
            current_count += 1
        except ParseError:
            log(f"api response is not valid xml for gotten from url: {str(instance_url)}")
            if "Please generate new bearer token" in instance.text:
                log("Error due to outdated token. Regenerating..")
                access_token = log_in_citeline_api(credentials, log)
            else:
                with open(instance_type + "_error.xml", "a") as x:
                    x.write(instance.text)
                if "NextPage" in instance.text:
                    instance_url = instance.text.split("<NextPage>")[1].split("</NextPage>")[0]
                    instance_url = instance_url.replace(";amp;", "%%%").replace("&amp;", "&").replace("%%%", ";")
                    log(f"continuing with page: {str(instance_url)}")
                    current_count += 1
                else:
                    if request_retries == 10:
                        log(f"could not find where to go next. Exiting. Retried {str(request_retries)} times")
                        exit(1)
                    else:
                        log(f"Invalid response. Retrying request ({str(request_retries)})")
                        time.sleep(20)
                        request_retries += 1


def uploading_files(log):
    log("Starting upload")
    from disqover.disqover_session import _InternalSession
    session = _InternalSession('http://metis', 8000)
    from disqover import SourceData

    sd = SourceData(session)

    plugin_storage_dir = Path('/plugin/external')

    dir = plugin_storage_dir / 'citeline'
    for item in dir.iterdir():
        if not item.is_file():
            continue
        log(f"uploading {item}")
        sd.upload_file(item, Path("citeline") / item.name)


def meta_data():
    return {
        'id': 'citeline_download',
        'name': 'Citeline Download (1.1)',
        'description': 'Download the citeline contents',
        'type-id': 'event-processor',
    }


def session_options_definition():
    return [
        {
            'content_type': 'text',
            'id': 'user_name',
            'name': 'Username',
            'description': 'Citeline Username'
        },
        {
            'content_type': 'text',
            'id': 'password',
            'name': 'Citeline Password',
            'description': 'Citeline Credentials'
        },
        {
            'content_type': 'text',
            'id': 'exclude',
            'name': 'Exclude a source',
            'description': 'Fill in (Trial, ... or None)'
        },
        {
            'content_type': 'bool',
            'id': 'incremental',
            'name': 'Incremental',
            'description': 'Switch on to incrementally download from citeline',
            'default': False
        },
        {
            'content_type': 'text',
            'id': 'corrupt',
            'name': 'ID corrupt files',
            'description': 'Fill the corrupt file_names from citeline in this box if any with "," separation'
        }
    ]


def process_events(events,
                   options_values,
                   log,
                   authenticator,
                   **kwargs
                   ):
    # ignoring event details
    usr = options_values["user_name"]
    pwd = options_values["password"]
    exclude = options_values["exclude"]
    incremental = options_values["incremental"]
    corrupt = options_values["corrupt"]

    corrupt_split = corrupt.split(",")
    exclude_split = exclude.split(",")
    entities = ["trial", "drug", "investigator", "organization"]
    credentials = fill_credentials(usr, pwd)
    num_cores = mp.cpu_count()

    if corrupt_split and incremental:
        log(f"Starting download of {corrupt_split} Corrupt files and incremental function gets started")
        access_token = log_in_citeline_api(credentials, log)
        for cor_id in corrupt_split:
            if ".xml" in cor_id:
                correct_id = re.sub(".xml", "", cor_id)
                instance_type = correct_id.split("_")[0]
                id_number = correct_id.split("_")[1]
                request_individual_instance_type(id_number, access_token, instance_type)
            else:
                instance_type = cor_id.split("_")[0]
                id_number = cor_id.split("_")[1]
                request_individual_instance_type(id_number, access_token, instance_type)
        log("corrupted files are downloaded")
        for src in entities:
            if src not in exclude_split:
                incremental_download(log, credentials, src, num_cores)
    elif corrupt_split:
        log(f"Starting download of {corrupt_split} Corrupt files")
        access_token = log_in_citeline_api(credentials, log)
        for cor_id in corrupt_split:
            if ".xml" in cor_id:
                correct_id = re.sub(".xml", "", cor_id)
                instance_type = correct_id.split("_")[0]
                id_number = correct_id.split("_")[1]
                request_individual_instance_type(id_number, access_token, instance_type)
            else:
                instance_type = cor_id.split("_")[0]
                id_number = cor_id.split("_")[1]
                request_individual_instance_type(id_number, access_token, instance_type)
    elif incremental:
        log("Starting Incremental files download")
        for src in entities:
            if src not in exclude_split:
                incremental_download(log, credentials, src, num_cores)
    else:
        log("Starting Full Download")
        for src in entities:
            if src not in exclude_split:
                full_download(log, credentials, src)
    log("Starting file upload to source_data")
    uploading_files(log)